import io
import boto3
import pyarrow.parquet as pq
import json 

def lambda_handler(event, context):
	buffer = io.BytesIO()
	s3 = boto3.resource('s3')
	#s3://aws-sam-cli-managed-default-samclisourcebucket-19ds6oib2zc2c/parquettest/userdata1.parquet
	s3_object = s3.Object('aws-sam-cli-managed-default-samclisourcebucket-19ds6oib2zc2c', 'parquettest/userdata1.parquet')
	s3_object.download_fileobj(buffer)
	table = pq.read_table(buffer)
	df = table.to_pandas()
	print(df)
	return {
		'statusCode': 200,
		'body': json.dumps('Hello from Lambda!')
	}
